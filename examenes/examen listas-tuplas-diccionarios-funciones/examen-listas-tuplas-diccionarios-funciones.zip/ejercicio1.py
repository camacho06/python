lista = [1, 2, 5, 8, 9, 9, 1, 5]
listaSinRepetidos = list(set(lista))
print(listaSinRepetidos)