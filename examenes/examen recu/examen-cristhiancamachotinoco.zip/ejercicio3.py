n = int(input("Dame el numero de filas de la piramide: "))
for i in range (1,n+1):
    print ("*"*n)
    n-=1