producto1 = "disco duro 500Gb,200,25,15"
producto2 = "memoria ram 16Gb,500,30,20"
producto3 = "ratón inalámbrico,800,12,10"
producto4 = "tarjeta wifi,150,20,12"
print ("Que producto de los 4 que hay quieres visualizar , 1 --> disco duro , 2 --> memoria ram , 3 --> raton inalambrico , 4 --> tarjeta wifi : ")
print ("selecciona ' exit ' para salir del modo visualizacion ")
peticion = input("Que producto quieres ver? : ")
if peticion == "1":
    print ()